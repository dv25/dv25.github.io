var UnoAppManifest = {
    lightThemeBackgroundColor: "#f00",
    darkThemeBackgroundColor: "#0f0",
    displayName: "Septimus",
    splashScreenImage: "splash_screen.scale-200.png",
    splashScreenColor: "#ffffff",
}