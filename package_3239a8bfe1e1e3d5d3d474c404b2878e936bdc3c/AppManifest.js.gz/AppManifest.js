var UnoAppManifest = {
    displayName: "UnoApp1",
    splashScreenImage: "splash_screen.scale-200.png",
    splashScreenColor: "#ffffff",
}